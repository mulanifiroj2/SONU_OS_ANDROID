SONU OS ANDROID KEYBOARD - PROJECT
==================================

SOURCE DESIGN BASELINE:
- app/src/main/assets/keyboard.html was copied from SONU_OS_STANDARD_COLOURS_V15.html.
- V15 dark-blue keys / green action controls and keyboard layout are retained.
- The page is hosted inside an Android InputMethodService, not inside a normal browser screen.

BUILD APK (FREE):
1. Upload the contents of this folder to a GitHub repository (root folder; do not upload the ZIP as a single file).
2. Open the repository's Actions tab.
3. Select "Build SONU OS APK" and press "Run workflow" (or push to main/master).
4. When the run completes, open its Artifacts section and download SONU-OS-debug-APK.
5. Extract the downloaded artifact and install app-debug.apk on the Android phone.

ENABLE ON ANDROID:
1. Open SONU OS Keyboard app.
2. Tap ENABLE SONU OS and enable it in Android settings.
3. Return to app and tap SELECT SONU OS KEYBOARD.
4. Choose SONU OS.
5. Open any app text field and select SONU OS if it is not already active.

IMPORTANT:
- This is a native Android Input Method (IME), intended to type in text fields across Android apps.
- Some apps restrict password, secure, or special fields; Android may hide third-party keyboards there.
- A few PC-only keys (Print Screen, Scroll Lock, Pause, Windows key, etc.) cannot perform PC system actions on Android; they remain UI controls / limited actions.
- This folder is Android project source. An APK has NOT been compiled or phone-tested in this environment.
- Debug APK is for installation/testing; it is not a Play Store release-signed APK.
