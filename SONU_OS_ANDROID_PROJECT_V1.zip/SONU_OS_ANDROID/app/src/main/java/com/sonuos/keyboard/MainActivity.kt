package com.sonuos.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(16, 20, 30))
        }
        val title = TextView(this).apply {
            text = "⌨️  SONU OS"
            textSize = 26f
            setTextColor(android.graphics.Color.WHITE)
        }
        val info = TextView(this).apply {
            text = "Enable SONU OS, then select it as your keyboard. It can then type in supported text fields across Android apps."
            textSize = 16f
            setTextColor(android.graphics.Color.LTGRAY)
            setPadding(0, 22, 0, 24)
        }
        val enable = Button(this).apply {
            text = "1. ENABLE SONU OS"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val choose = Button(this).apply {
            text = "2. SELECT SONU OS KEYBOARD"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(enable)
        root.addView(choose)
        setContentView(root)
    }
}
