package com.sonuos.keyboard

import android.inputmethodservice.InputMethodService
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.KeyEvent
import android.view.View
import android.view.Gravity
import android.widget.FrameLayout
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper

class SonuInputMethodService : InputMethodService() {
    private var web: WebView? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreateInputView(): View {
        val frame = FrameLayout(this)
        val wv = WebView(this)
        web = wv
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = true
        wv.settings.allowContentAccess = false
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.webViewClient = WebViewClient()
        wv.webChromeClient = WebChromeClient()
        wv.addJavascriptInterface(NativeBridge(), "AndroidIme")
        frame.addView(wv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        wv.loadUrl("file:///android_asset/keyboard.html")
        frame.layoutParams = FrameLayout.LayoutParams(-1, dp(430))
        return frame
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        syncPreview()
    }

    override fun onUpdateSelection(oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int, candidatesStart: Int, candidatesEnd: Int) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        syncPreview()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun syncPreview() {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(120, 0)?.toString().orEmpty()
        val selected = ic.getSelectedText(0)?.toString().orEmpty()
        val after = ic.getTextAfterCursor(80, 0)?.toString().orEmpty()
        val preview = (before + selected + after).takeLast(240)
        val safe = org.json.JSONObject.quote(preview)
        mainHandler.post { web?.evaluateJavascript("window.syncNativeText && window.syncNativeText($safe)", null) }
    }

    inner class NativeBridge {
        @JavascriptInterface fun commitText(text: String) {
            currentInputConnection?.commitText(text, 1)
            syncPreview()
        }
        @JavascriptInterface fun replaceSelection(text: String) {
            currentInputConnection?.commitText(text, 1)
            syncPreview()
        }
        @JavascriptInterface fun keyAction(action: String) {
            val ic = currentInputConnection ?: return
            when (action) {
                "Backspace" -> ic.deleteSurroundingText(1, 0)
                "Delete" -> ic.deleteSurroundingText(0, 1)
                "Enter" -> sendKey(ic, KeyEvent.KEYCODE_ENTER)
                "Space" -> ic.commitText(" ", 1)
                "Tab" -> ic.commitText("\t", 1)
                "ArrowLeft" -> sendKey(ic, KeyEvent.KEYCODE_DPAD_LEFT)
                "ArrowRight" -> sendKey(ic, KeyEvent.KEYCODE_DPAD_RIGHT)
                "ArrowUp" -> sendKey(ic, KeyEvent.KEYCODE_DPAD_UP)
                "ArrowDown" -> sendKey(ic, KeyEvent.KEYCODE_DPAD_DOWN)
                "Home" -> sendKey(ic, KeyEvent.KEYCODE_MOVE_HOME)
                "End" -> sendKey(ic, KeyEvent.KEYCODE_MOVE_END)
            }
            syncPreview()
        }
        @JavascriptInterface fun editAction(action: String) {
            val ic = currentInputConnection ?: return
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            when (action) {
                "select" -> ic.performContextMenuAction(android.R.id.selectAll)
                "copy" -> {
                    val selected = ic.getSelectedText(0)?.toString().orEmpty()
                    if (selected.isNotEmpty()) clipboard.setPrimaryClip(ClipData.newPlainText("SONU OS", selected))
                    else ic.performContextMenuAction(android.R.id.copy)
                }
                "cut" -> ic.performContextMenuAction(android.R.id.cut)
                "paste" -> {
                    if (clipboard.hasPrimaryClip()) {
                        val clip = clipboard.primaryClip
                        val text = clip?.getItemAt(0)?.coerceToText(this@SonuInputMethodService)?.toString()
                        if (!text.isNullOrEmpty()) ic.commitText(text, 1)
                    } else ic.performContextMenuAction(android.R.id.paste)
                }
                "delete" -> ic.deleteSurroundingText(0, 1)
            }
            syncPreview()
        }
        @JavascriptInterface fun vibrateKey() {
            try { getSystemService(android.os.Vibrator::class.java)?.vibrate(android.os.VibrationEffect.createOneShot(18, 45)) } catch (_: Exception) { }
        }
    }

    private fun sendKey(ic: android.view.inputmethod.InputConnection, code: Int) {
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
